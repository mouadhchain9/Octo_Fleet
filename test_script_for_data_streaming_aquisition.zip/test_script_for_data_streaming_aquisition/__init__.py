import octoprint.plugin
import paho.mqtt.publish as publish
import json
from octoprint.util import RepeatedTimer

class MotionMqttPlugin(
    octoprint.plugin.StartupPlugin,
    octoprint.plugin.TemplatePlugin,
    octoprint.plugin.EventHandlerPlugin,
    octoprint.plugin.ProgressPlugin
):

    def on_after_startup(self):
        self._logger.info("Enhanced Telemetry MQTT Plugin started")
        self.state = {
            "x": 0, "y": 0, "z": 0, "e": 0, "f": 0, 
            "cmdIndex": 0,
            "is_extruding": False,
            "is_printing": False,
            "is_paused": False,
            "progress": 0,
            "file_name": None,
            "temp": {
                "nozzle": 0, "nozzleTarget": 0,
                "bed": 0, "bedTarget": 0
            }
        }
        self.cmd_index = 0
        self._temp_timer = RepeatedTimer(2.0, self._send_thermal_telemetry)
        self._temp_timer.start()

    def _send_thermal_telemetry(self):
        temps = self._printer.get_current_temperatures()
        if not temps: return

        # Safe dictionary getters to avoid NoneType attribute errors
        t0 = temps.get("tool0") or {}
        bed = temps.get("bed") or {}

        self.state["temp"]["nozzle"] = t0.get("actual", 0) or 0
        self.state["temp"]["nozzleTarget"] = t0.get("target", 0) or 0
        self.state["temp"]["bed"] = bed.get("actual", 0) or 0
        self.state["temp"]["bedTarget"] = bed.get("target", 0) or 0
        
        self.state["is_printing"] = self._printer.is_printing()
        self.state["is_paused"] = self._printer.is_paused()

        self._publish("octoPrint/temperature", self.state)

    def gcode_sent(self, comm_instance, phase, cmd, cmd_type, gcode, *args, **kwargs):
        # 1. Clean G-code comments to prevent telemetry hijacking
        cmd_clean = cmd.split(';')[0].strip()
        if not cmd_clean: return

        # 2. Track indexing
        if cmd_clean.startswith(("G0", "G1", "G2", "G3", "G4", "G28", "G92")):
            self.cmd_index += 1
            self.state["cmdIndex"] = self.cmd_index
            self.state["is_extruding"] = ("E" in cmd_clean and (cmd_clean.startswith("G1") or "X" in cmd_clean or "Y" in cmd_clean))

        # 3. Handle Extrusion Reset (G92)
        if cmd_clean.startswith("G92") and "E" in cmd_clean:
            try:
                for p in cmd_clean.split():
                    if p.startswith("E"): self.state["e"] = float(p[1:])
            except: pass
            return

        # 4. Handle Printer Homing Reset (G28)
        if cmd_clean.startswith("G28"):
            self.state["x"] = 0.0
            self.state["y"] = 0.0
            self.state["z"] = 0.0
            self.state["is_printing"] = self._printer.is_printing()
            self.state["is_paused"] = self._printer.is_paused()
            self._publish("octoPrint/motion", self.state)
            return

        # 5. Handle Movement (G0/G1)
        if not (cmd_clean.startswith("G1") or cmd_clean.startswith("G0")):
            return

        parts = cmd_clean.split()
        updated = False
        for p in parts:
            try:
                if p.startswith("X"): self.state["x"] = float(p[1:]); updated = True
                elif p.startswith("Y"): self.state["y"] = float(p[1:]); updated = True
                elif p.startswith("Z"): self.state["z"] = float(p[1:]); updated = True
                elif p.startswith("E"): self.state["e"] = float(p[1:]); updated = True
                elif p.startswith("F"): self.state["f"] = float(p[1:]); updated = True
            except: pass

        if updated:
            self.state["is_printing"] = self._printer.is_printing()
            self.state["is_paused"] = self._printer.is_paused()
            self._publish("octoPrint/motion", self.state)

    def on_print_progress(self, storage, path, progress):
        self.state["progress"] = progress
        
        current_data = self._printer.get_current_data() or {}
        progress_info = current_data.get("progress") or {}
        
        time_elapsed = progress_info.get("printTime") or 0
        time_left = progress_info.get("printTimeLeft") or 0
        
        payload = {
            "progress": progress,
            "time_elapsed": time_elapsed,
            "time_left": time_left,
            "is_printing": self._printer.is_printing(),
            "is_paused": self._printer.is_paused()
        }
        self._publish("octoPrint/progress/printing", payload)


    def on_event(self, event, payload):
        self._publish(f"octoPrint/event/{event.lower()}", payload)

    def _publish(self, topic, data):
        try:
            publish.single(topic, json.dumps(data), hostname="localhost", port=1883)
        except Exception as e:
            self._logger.error(f"MQTT failed on {topic}: {e}")

__plugin_name__ = "Enhanced Telemetry Plugin"
__plugin_implementation__ = MotionMqttPlugin()

def __plugin_load__():
    global __plugin_implementation__
    __plugin_implementation__ = MotionMqttPlugin()
    global __plugin_hooks__
    __plugin_hooks__ = {
        "octoprint.comm.protocol.gcode.sent": __plugin_implementation__.gcode_sent
    }