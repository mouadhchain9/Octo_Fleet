import sqlite3
import json
import time
import paho.mqtt.client as mqtt

# ==========================
# DB SETUP
# ==========================
conn = sqlite3.connect("telemetry.db", check_same_thread=False)
cursor = conn.cursor()
cursor.execute("""
CREATE TABLE IF NOT EXISTS telemetry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp REAL,
    x REAL, y REAL, z REAL, e REAL, f REAL,
    nozzle_actual REAL, nozzle_target REAL,
    bed_actual REAL, bed_target REAL,
    progress REAL, state TEXT
)
""")
conn.commit()

state = {
    "x": 0.0, "y": 0.0, "z": 0.0, "e": 0.0, "f": 0.0,
    "nozzle_actual": 0.0, "nozzle_target": 0.0,
    "bed_actual": 0.0, "bed_target": 0.0,
    "progress": 0.0, "state": "STARTING",
    "layer_current": 0, "layer_total": 0,
    "time_elapsed": 0, "time_left": 0
}

def on_connect(client, userdata, flags, rc):
    print("Connected to MQTT Broker. Monitoring printer...")
    client.subscribe("octoPrint/#")

def on_message(client, userdata, msg):
    global state
    try:
        data = json.loads(msg.payload.decode())
    except: return

    topic = msg.topic
    should_save = False

    if topic == "octoPrint/motion":
        state.update({
            "x": data.get("x", 0.0) or 0.0,
            "y": data.get("y", 0.0) or 0.0,
            "z": data.get("z", 0.0) or 0.0,
            "e": data.get("e", 0.0) or 0.0,
            "f": data.get("f", 0.0) or 0.0
        })
        should_save = True

    elif topic == "octoPrint/temperature":
        temps = data.get("temp", {}) or {}
        state.update({
            "nozzle_actual": temps.get("nozzle", 0.0) or 0.0,
            "nozzle_target": temps.get("nozzleTarget", 0.0) or 0.0,
            "bed_actual": temps.get("bed", 0.0) or 0.0,
            "bed_target": temps.get("bedTarget", 0.0) or 0.0
        })
        state["state"] = "PAUSED" if data.get("is_paused") else ("PRINTING" if data.get("is_printing") else "IDLE")
        should_save = True

    elif topic == "octoPrint/progress/printing":
        state["progress"] = data.get("progress", 0.0) or 0.0
        state["time_elapsed"] = data.get("time_elapsed", 0) or 0
        state["time_left"] = data.get("time_left", 0) or 0
        should_save = True

    elif topic == "octoPrint/plugins/DisplayLayerProgress/values":
        layer_info = data.get("layer", {}) or {}
        state["layer_current"] = int(layer_info.get("current", 0) or 0)
        state["layer_total"] = int(layer_info.get("total", 0) or 0)
        should_save = True

    elif "octoPrint/event/" in topic:
        event_name = topic.split("/")[-1]
        if event_name == "displaylayerprogress_layerchanged":
            state["layer_current"] = int(data.get("currentLayer") or data.get("current") or 0)
            state["layer_total"] = int(data.get("totalLayerCount") or data.get("total") or 0)
            should_save = True
        elif event_name in ["printstarted", "printdone", "printfailed", "printcancelled"]:
            state["state"] = event_name.upper()
            should_save = True

    if should_save:
        # SQLite storage commented out for testing, keeping uncommented scope for Indentation safety
        # cursor.execute("""
        #     INSERT INTO telemetry (timestamp, x, y, z, e, f, nozzle_actual, nozzle_target, bed_actual, bed_target, progress, state)
        #     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        # """, (time.time(), state["x"], state["y"], state["z"], state["e"], state["f"],
        #       state["nozzle_actual"], state["nozzle_target"], state["bed_actual"], state["bed_target"],
        #       state["progress"], state["state"]))
        # conn.commit()

        # CLEAN ONE-LINE DASHBOARD (safe from NoneType string formatting errors)
        # CLEAN ONE-LINE DASHBOARD (safe from NoneType string formatting errors)
        el_h = int(state["time_elapsed"] // 3600)
        el_m = int((state["time_elapsed"] % 3600) // 60)
        el_s = int(state["time_elapsed"] % 60)
        
        rem_h = int(state["time_left"] // 3600)
        rem_m = int((state["time_left"] % 3600) // 60)
        rem_s = int(state["time_left"] % 60)

        log_line = (
            f"[{state['state']:<10}] "
            f"X:{state['x']:>6.1f} Y:{state['y']:>6.1f} Z:{state['z']:>5.2f} | "
            f"E:{state['e']:>8.1f} F:{state['f']:>5.0f} | "
            f"T:{state['nozzle_actual']:>3.0f}/{state['nozzle_target']:>3.0f} "
            f"B:{state['bed_actual']:>2.0f}/{state['bed_target']:>2.0f} | "
            f"L:{state['layer_current']}/{state['layer_total']} | "
            f"{state['progress']:>3.0f}% | "
            f"Time:{el_h:02d}:{el_m:02d}:{el_s:02d} / "
            f"Left:{rem_h:02d}:{rem_m:02d}:{rem_s:02d}"
        )
        print(log_line)

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message
client.connect("localhost", 1883, 60)
client.loop_forever()